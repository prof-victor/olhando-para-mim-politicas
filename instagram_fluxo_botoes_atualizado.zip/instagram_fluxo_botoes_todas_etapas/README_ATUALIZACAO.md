ATUALIZAÇÃO — BOTÕES EM TODAS AS ETAPAS

1. Faça uma cópia de segurança da pasta atual.
2. Extraia este ZIP e copie os arquivos para a pasta do projeto, substituindo os arquivos correspondentes.
3. NÃO substitua o arquivo .env.
4. No terminal do servidor, pressione Ctrl+C.
5. Inicie novamente o servidor com o mesmo comando usado anteriormente.
6. No Instagram, envie “menu” e teste os botões do menu, depois Grupo > Detalhes sobre o grupo.

O main.py agora carrega as telas de fluxo_aprovado.json, envia respostas rápidas em cada tela e encaminha os cliques para a próxima tela pelo payload do botão. O estado e os dados do cadastro ficam temporariamente na memória e se perdem quando o servidor reinicia. Teste no Instagram e observe o terminal: a API da Meta pode rejeitar botões conforme permissões, versão ou formato da conta.


CORREÇÃO DE RESPOSTAS SEM BOTÕES

- Respostas livres geradas pela IA agora recebem três respostas rápidas: Conhecer grupo, Individual e Menu principal.
- Mensagens de validação/erro que não especificam botões também recebem essas opções.
- Os botões gerais encaminham para telas já existentes no fluxo aprovado.
- Mensagens das telas mantêm os botões específicos definidos em fluxo_aprovado.json.

Após substituir os arquivos, reinicie o Uvicorn. O arquivo .env não está incluído nem deve ser substituído.


Ajuste adicional: todos os botões que retornam ao menu principal exibem apenas o título curto "Menu".


Revisão de títulos: os rótulos dos botões foram encurtados para evitar truncamento no Instagram. O botão “🫶 Detalhes sobre o grupo” aparece como “🫶 Detalhes do grupo”, preservando o sentido e respeitando o limite visual da resposta rápida. “Menu” permanece como rótulo do menu principal.


## Ajuste solicitado em 29/10/2026
- Removidos os botões de confirmação das etapas A5–A9 e B5–B9.
- Mantido o botão de correção em B10 e incluído em A10, direcionando para CORRIGIR_A/CORRIGIR_B.
- O botão de confirmação de B10 foi preservado.
